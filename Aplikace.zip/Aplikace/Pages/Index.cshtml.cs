using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using MQTTnet;
using Newtonsoft.Json.Linq;
using PredikceVyt�ov�n�FVE.Data;
using PredikceVyt�ov�n�FVE.Helpers;
using PredikceVyt�ov�n�FVE.Models;
using PredikceVyt�ov�n�FVE.Services;


namespace PredikceVyt�ov�n�FVE.Pages
{
    public class IndexModel(MqttDataService mqttData) : PageModel
    {

        public MqttData initData = new();
        public List<int> Battery = [];
        public List<DateTime> timestamps = [];
        public List<float> Consumption = [];
        public List<float> Production = [];
        public List<float> Grid = [];
        public DateTime LastUpdate;

        [BindProperty]
        public DateTime DataDate { get; set; } = DateTime.Now;

        public void OnGet()
        {
            GetData();
        }

        public void GetData()
        {
            var chartData = mqttData.GetMqttDataByDate(DataDate);

            chartData = DataFilterHelper.FilterDateTime(chartData, new TimeSpan(0,15,0));

            if (chartData.Count != 0)
            {
                initData = chartData.Last();
                LastUpdate = ConverterHelper.ToDateTime(initData.Date, initData.Time);
            }
            timestamps = chartData.Select(x => ConverterHelper.ToDateTime(x.Date, x.Time)).ToList();
            Battery = chartData.Where(x => x.SoC != null).Select(x => (int)x.SoC!).ToList();
            Production = chartData.Where(x => x.P_PV != null).Select(x => (float)x.P_PV!).ToList();
            Consumption = chartData.Where(x => x.P_HOME != null).Select(x => (float)x.P_HOME!).ToList();
            Grid = chartData.Where(x => x.P_GRID != null).Select(x => (float)-x.P_GRID!).ToList();
        } 

    }
}
